function varargout = FV_Tool(varargin)
% FV_TOOL MATLAB code for FV_Tool.fig
%      FV_TOOL, by itself, creates a new FV_TOOL or raises the existing
%      singleton*.
%
%      H = FV_TOOL returns the handle to a new FV_TOOL or the handle to
%      the existing singleton*.
%
%      FV_TOOL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in FV_TOOL.M with the given input arguments.
%
%      FV_TOOL('Property','Value',...) creates a new FV_TOOL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before FV_Tool_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to FV_Tool_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help FV_Tool

% Last Modified by GUIDE v2.5 13-Aug-2023 01:28:51

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @FV_Tool_OpeningFcn, ...
                   'gui_OutputFcn',  @FV_Tool_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before FV_Tool is made visible.
function FV_Tool_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to FV_Tool (see VARARGIN)

% Choose default command line output for FV_Tool
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes FV_Tool wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = FV_Tool_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global fname pname
cd  DB_Sound\
[fname,pname]=uigetfile('*.wav','Select the audio input file from Database');
cd ..
%% Reading the Input Audio Signal using AudioREader
tty = strcat(pname,fname)
[y,Fs] = audioread(tty);
% % sound(y,Fs); % playing the input audio
figure,plot(y) % plot the input audio signal
xlabel('No of Samples')
ylabel('Amplitude')
fs=Fs; % sample frequency
signal = y(:,1);
%% Calculating the Periodogram-Power Spectral Density of the Input Sgnal
figure,plot(psd(spectrum.periodogram,signal,'Fs',fs,'NFFT',length(signal)));
%% Initilaizing the Digital Filter Design
disp('Press 1 for Low Pass FIR')
disp('Press 2 for High Pass FIR')
op= input('Enter the Number for Choosing the Filter (Either LowPass or HighPass FIR Filter : ');

if op==1 % Lopw Pass FIR Filter
    
          lpFilt = designfilt('lowpassfir','PassbandFrequency',0.25, ...
                        'StopbandFrequency',0.35,'PassbandRipple',0.5, ...
                         'StopbandAttenuation',65,'DesignMethod','kaiserwin');
            fvtool(lpFilt,'Analysis','freq')

            dataIn = y;
            dataOut = filter(lpFilt,dataIn);
           %  sound(dataOut,Fs);
            audiowrite('LowPass_FIR_Filtered_Output.wav',dataOut,Fs);
            % Output the filter coefficients for Low Pass FIR Filter
% % %             sos = lpFilt.Coefficients
            % 
            noisevar1 = abs(estimatenoise(y',2)) % noise level estimation for input signal
            noisevar2 = abs(estimatenoise(dataOut',2)) % noise level estimation for output signal

        % peak signal-to-noise ratio-PSNR, mean square error-MSE
        % maximum squared error- MAXERR, ratio of squared norms- L2RAt    
        [psnr,mse,maxerr,L2rat] = measerr(y, dataOut)%
            [ssimval, ssimmap] = ssim(y, dataOut);
            correlate=corr2(y, dataOut)
elseif op==2 % High Pass FIR Filter

           hpFilt = designfilt('highpassfir','StopbandFrequency',0.25, ...
                        'PassbandFrequency',0.35,'PassbandRipple',0.5, ...
                        'StopbandAttenuation',65,'DesignMethod','kaiserwin');
            fvtool(hpFilt)

            dataIn = y;
            dataOut = filter(hpFilt,dataIn);
          % sound(dataOut,Fs);
            audiowrite('HighPass_FIR_Filtered_Output.wav',dataOut,Fs);
            % Output the filter coefficients for High Pass FIR Filter
            sos = hpFilt.Coefficients
            % Noise Estimation
            noisevar1 = abs(estimatenoise(y',2)) % noise level estimation for input signal
            noisevar2 = abs(estimatenoise(dataOut',2)) % noise level estimation for output signal


        % peak signal-to-noise ratio-PSNR, mean square error-MSE
        % maximum squared error- MAXERR, ratio of squared norms- L2rat    
                    [psnr,mse,maxerr,L2rat] = measerr(y, dataOut)%
                    [ssimval, ssimmap] = ssim(y, dataOut);
                    correlate=corr2(y, dataOut)

else 
    return
end



% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
ML_Analysis


% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% % cd  DB_Sound\
% % [fname,pname]=uigetfile('*.wav','Select the audio input file from Database');
% % cd ..
global fname pname
cd  DB_Sound\
[fname,pname]=uigetfile('*.wav','Select the audio input file from Database');
cd ..
[x,Fs] = audioread(strcat(pname,fname)); %%'1-172649-A-40_1.wav'
fs = Fs;
soundsc(x,Fs); % play sound

y=x;
Y=stft(y,Fs);
L= (1:length(Y))*Fs/length(Y);
figure,plot(L,abs(Y))
xlabel('Frequency');
ylabel('Amplitude');
title('(Magnitude Spectrum')
windowSize = 256;
windowOverlap = [];
freqRange = 0:Fs;
figure,spectrogram(y(:,1), windowSize, windowOverlap, freqRange, Fs, 'xaxis')

%%
%%
kk=117000;k = 1;

[rr1,cc1] = size(freqRange);
dt = 1/freqRange(cc1);
t=0:dt:(k*dt)-dt;                    
S = zeros(501,117);
windowlength = 1e3;
k = 1;
for jj = 1:117
    y = x(k:k+windowlength-1)';
    ydft = fft(y).*gausswin(1e3);
    S(:,jj) = ydft(1:501);
    k = k+windowlength;
end
F = 0:(freqRange-1)/1000:(freqRange-1)/2;
T = 0:(1e3*dt):(kk*dt)-(1e3*dt);
figure,surf(T,F,20*log10(abs(S)),'EdgeColor','none')
axis xy; axis tight; colormap(cool); view(0,90);
xlabel('Time (sec)');
ylabel('Frequency (Hz)');
set(gca,'YDir','Normal')
xlabel('Time (secs)')
ylabel('Freq (Hz)')
title('STFT - Short-time Fourier Transform spectrum')
