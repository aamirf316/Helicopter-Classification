clc
clear all
close all
%% read/gather the target class info
[num,txt,raw]=xlsread('namess.xlsx');
label_data = txt;
%% read the DB info
cd DB_Sound\

kk = pwd;
filePattern = fullfile(kk, '*.wav') %identify 'wav files
wavFiles = dir(filePattern) %use dir to list 'wav. files
size1 = length(wavFiles); % length of the size of the file


Dfeat = [];
wt = waitbar(0,'Please Wait....');

for tt=1:size1    

  [x,Fs] = audioread(strcat('1-172649-A-40_',num2str(tt),'.wav'));
    Y=stft(x,Fs);
    L= (1:length(Y))*Fs/length(Y);
    
    [cA1,cH1,cV1,cD1] = dwt2(x,'db4');
[cA2,cH2,cV2,cD2] = dwt2(cA1,'db4');
[cA3,cH3,cV3,cD3] = dwt2(cA2,'db4');

DWT_feat = [cA3,cH3,cV3,cD3];
G = pca(DWT_feat);
whos DWT_feat
whos G
g = graycomatrix(G);
stats = graycoprops(g,'Contrast Correlation Energy Homogeneity');
Contrast = stats.Contrast;
Correlation = stats.Correlation;
Energy = stats.Energy;
Homogeneity = stats.Homogeneity;
Mean = mean2(G);
Standard_Deviation = std2(G);
Entropy = entropy(G);
RMS = mean2(rms(G));
%Skewness = skewness(img)
Variance = mean2(var(double(G)));
a = sum(double(G(:)));
Smoothness = 1-(1/(1+a));
Kurtosis = kurtosis(double(G(:)));
Skewness = skewness(double(G(:)));
% Inverse Difference Movement
m = size(G,1);
n = size(G,2);
in_diff = 0;
for i = 1:m
    for j = 1:n
        temp = G(i,j)./(1+(i-j).^2);
        in_diff = in_diff+temp;
    end
end
IDM = double(in_diff);
    
Dfeat(tt,:) = [Contrast,Correlation,Energy,Homogeneity, Mean, Standard_Deviation, Entropy, RMS, Variance, Smoothness, Kurtosis, Skewness, IDM];

 clear cA1 cH1 cV1 cD1 cA2 cD2 cV2 cH2  m n x  hh seg_img imgr mean_cluster_val idx wholeG Ik indexk k wholeD maxU n data M N img level gray I center U obj_fcn
clear IDM in_diff m n Contrast Correlation Energy Homogeneity Mean Standard_Deviation Entropy RMS Variance Smoothness Kurtosis Skewness IDM DWT_feat G cA3 cH3 cV3 cD3
clear filename pathname a g i j result stats temp smth P flg 
  
end

cd ..

save DataBase_Feature Dfeat label_data
