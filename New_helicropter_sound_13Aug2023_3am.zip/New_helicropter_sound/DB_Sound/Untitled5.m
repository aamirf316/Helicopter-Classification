clc
clear all
close all
%%
[x,Fs] = audioread('1-172649-A-40_1.wav');
y=x;
Y=stft(y,Fs);
L= (1:length(Y))*Fs/length(Y);
figure,plot(L,abs(Y))
xlabel('Frequency');
ylabel('Amplitude');
title('(Magnitude Spectrum')
windowSize = 256;
windowOverlap = [];
freqRange = 0:Fs;
figure,spectrogram(y(:,1), windowSize, windowOverlap, freqRange, Fs, 'xaxis')

%%
%%
kk=117000;k = 1;

[rr1,cc1] = size(freqRange);
dt = 1/freqRange(cc1);
t=0:dt:(k*dt)-dt;                    
S = zeros(501,117);
windowlength = 1e3;
k = 1;
for jj = 1:117
    y = x(k:k+windowlength-1)';
    ydft = fft(y).*gausswin(1e3);
    S(:,jj) = ydft(1:501);
    k = k+windowlength;
end
F = 0:(freqRange-1)/1000:(freqRange-1)/2;
T = 0:(1e3*dt):(kk*dt)-(1e3*dt);
figure,surf(T,F,20*log10(abs(S)),'EdgeColor','none')
axis xy; axis tight; colormap(cool); view(0,90);
xlabel('Time (sec)');
ylabel('Frequency (Hz)');
set(gca,'YDir','Normal')
xlabel('Time (secs)')
ylabel('Freq (Hz)')
title('STFT - Short-time Fourier Transform spectrum')