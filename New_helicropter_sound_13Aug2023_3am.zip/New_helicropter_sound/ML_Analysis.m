function varargout = ML_Analysis(varargin)
% ML_ANALYSIS MATLAB code for ML_Analysis.fig
%      ML_ANALYSIS, by itself, creates a new ML_ANALYSIS or raises the existing
%      singleton*.
%
%      H = ML_ANALYSIS returns the handle to a new ML_ANALYSIS or the handle to
%      the existing singleton*.
%
%      ML_ANALYSIS('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in ML_ANALYSIS.M with the given input arguments.
%
%      ML_ANALYSIS('Property','Value',...) creates a new ML_ANALYSIS or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ML_Analysis_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ML_Analysis_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help ML_Analysis

% Last Modified by GUIDE v2.5 31-May-2022 13:11:31

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ML_Analysis_OpeningFcn, ...
                   'gui_OutputFcn',  @ML_Analysis_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ML_Analysis is made visible.
function ML_Analysis_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ML_Analysis (see VARARGIN)

% Choose default command line output for ML_Analysis
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ML_Analysis wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ML_Analysis_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
aa = pwd;
%% Import the Data
load DataBase_Feature.mat
target_class = label_data;

XX = Dfeat;
YY = target_class;

 %% Test/Query Input Data
 cd DB_Sound\
[fname,pname]=uigetfile('*.wav','Select the audio input file from Database');

[x,Fs] = audioread(strcat(pname,fname)); %%'1-172649-A-40_1.wav'
%%
cd ..
    Y=stft(x,Fs);
    L= (1:length(Y))*Fs/length(Y);
    
    [cA1,cH1,cV1,cD1] = dwt2(x,'db4');
[cA2,cH2,cV2,cD2] = dwt2(cA1,'db4');
[cA3,cH3,cV3,cD3] = dwt2(cA2,'db4');

DWT_feat = [cA3,cH3,cV3,cD3];
G = pca(DWT_feat);
whos DWT_feat
whos G
g = graycomatrix(G);
stats = graycoprops(g,'Contrast Correlation Energy Homogeneity');
Contrast = stats.Contrast;
Correlation = stats.Correlation;
Energy = stats.Energy;
Homogeneity = stats.Homogeneity;
Mean = mean2(G);
Standard_Deviation = std2(G);
Entropy = entropy(G);
RMS = mean2(rms(G));
%Skewness = skewness(img)
Variance = mean2(var(double(G)));
a = sum(double(G(:)));
Smoothness = 1-(1/(1+a));
Kurtosis = kurtosis(double(G(:)));
Skewness = skewness(double(G(:)));
% Inverse Difference Movement
m = size(G,1);
n = size(G,2);
in_diff = 0;
for i = 1:m
    for j = 1:n
        temp = G(i,j)./(1+(i-j).^2);
        in_diff = in_diff+temp;
    end
end
IDM = double(in_diff);
    
Qfeat = [Contrast,Correlation,Energy,Homogeneity, Mean, Standard_Deviation, Entropy, RMS, Variance, Smoothness, Kurtosis, Skewness, IDM];

%%
Y = YY; X = XX;
%% ANN (Probabilistic neural network)
% QF=Qfeature;
Tc1 = [ones(1,7) 1 + ones(1,9) 2 + ones(1,10) 3 + ...
    ones(1,6) 4 + ones(1,7) 5];  
TE1 = ind2vec(Tc1);
disp(size(Tc1))
disp(size(TE1))

%% random data
QF = [Qfeat(:,:)];
%% recog or not
size(TE1)
DF=[];
DF = [DF XX'];
net1 = newpnn(DF,TE1)
view(net1)
size(net1)
size(QF)
Y1 = sim(net1,QF');

out1 = vec2ind(Y1);
 
%% Confusion Matrix
outputs1 = net1(DF);
errors1 = gsubtract(TE1,outputs1); 
figure, plotconfusion(TE1,outputs1)

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
aa = pwd;
%% Import the Data
load DataBase_Feature.mat
target_class = label_data;

XX = Dfeat;
YY = target_class;
%% Data Split 75% for Training & 25% for Test
NN = size(Dfeat,1);
rng('default') % For reproducibility
Partition = cvpartition(YY,'Holdout',0.23,'Stratify',true );%% 
test_data = test(Partition); % Indices for the test set
X_test = XX(test_data,:);
Y_test = YY(test_data);
%% SVM
t = templateSVM('Standardize',true)
Mdl = fitcecoc(XX,YY,'Learners',t,'CVPartition',Partition,'ScoreTransform','logit',...
                'ClassNames',{'AH-1 Cobra','UH-60 Black Hawak','A109 Agusta'...
               'AS332 Super Puma','Mil MI-2 Hoplite'}); %%%'CrossVal','on'
Mdl.CrossValidatedModel


Mdl.ScoreTransform
Mdl.NumObservations
CMdl_1 = Mdl.Trained{1};

%% Random Smaple
idx = randsample(sum(test_data),Partition.TestSize);
%% Prediction
[predict_labels1,PostProbs1,MisClassCost1] = predict(CMdl_1,X_test);

table(Y_test(idx),predict_labels1(idx),'VariableNames',...
    {'True_Label','Predicted_Label'})

XXX_1 = table(Y_test(idx),predict_labels1(idx),PostProbs1(idx),'VariableNames',...
    {'True_Labels','Predicted_Labels',...
    'PosteriorProbabilities'})

mdl_1_catt1 = categorical(table2array(XXX_1(:,1))); % True Label
mdl_1_catt2 = categorical(table2array(XXX_1(:,2))); % Predicted Label
%% Confusion matrix
figure,
cm_1 = confusionchart(mdl_1_catt1,mdl_1_catt2)
%% Add column and row summaries.
cm_1.RowSummary = 'row-normalized';
cm_1.ColumnSummary = 'column-normalized';
cm_1.Normalization = 'absolute'

%%



% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
aa = pwd;
%% Import the Data
load DataBase_Feature.mat
target_class = label_data;

XX = Dfeat;
YY = target_class;
%% Data Split 75% for Training & 25% for Test
NN = size(Dfeat,1);
rng('default') % For reproducibility
Partition = cvpartition(YY,'Holdout',0.23,'Stratify',true );%% 
test_data = test(Partition); % Indices for the test set
X_test = XX(test_data,:);
Y_test = YY(test_data);
%%
t = templateKNN('Standardize',true,'NumNeighbors',3)

Mdl = fitcecoc(XX,YY,'Learners',t,'CVPartition',Partition,  'ScoreTransform','logit',...
             'ClassNames',{'AH-1 Cobra','UH-60 Black Hawak','A109 Agusta'...
               'AS332 Super Puma','Mil MI-2 Hoplite'}); %%%'CrossVal','on'
Mdl.CrossValidatedModel



Mdl.ScoreTransform
Mdl.NumObservations
CMdl_1 = Mdl.Trained{1};

%% Random Smaple
idx = randsample(sum(test_data),Partition.TestSize);
%% Prediction
[predict_labels1,PostProbs1,MisClassCost1] = predict(CMdl_1,X_test);

table(Y_test(idx),predict_labels1(idx),'VariableNames',...
    {'True_Label','Predicted_Label'})

XXX_1 = table(Y_test(idx),predict_labels1(idx),PostProbs1(idx),'VariableNames',...
    {'True_Labels','Predicted_Labels',...
    'PosteriorProbabilities'})

mdl_1_catt1 = categorical(table2array(XXX_1(:,1))); % True Label
mdl_1_catt2 = categorical(table2array(XXX_1(:,2))); % Predicted Label
%% Confusion matrix
figure,
cm_1 = confusionchart(mdl_1_catt1,mdl_1_catt2)
%% Add column and row summaries.
cm_1.RowSummary = 'row-normalized';
cm_1.ColumnSummary = 'column-normalized';
cm_1.Normalization = 'absolute'
%%



% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
aa = pwd;
%% Import the Data
%% Import the Data
load DataBase_Feature.mat
target_class = label_data;

XX = Dfeat;
YY = target_class;
%% Data Split 75% for Training & 25% for Test
NN = size(Dfeat,1);
rng('default') % For reproducibility
Partition = cvpartition(YY,'Holdout',0.18,'Stratify',true );%% 
test_data = test(Partition); % Indices for the test set
X_test = XX(test_data,:);
Y_test = YY(test_data);
%% Naive Bayes
% t = templateNaiveBayes('DistributionNames','kernel');

Mdl = fitcnb(XX,YY,'CVPartition',Partition,'ScoreTransform','logit',...
                'ClassNames',{'AH-1 Cobra','UH-60 Black Hawak','A109 Agusta'...
               'AS332 Super Puma','Mil MI-2 Hoplite'}); %%%'CrossVal','on'
Mdl.CrossValidatedModel


Mdl.ScoreTransform
Mdl.NumObservations
CMdl_1 = Mdl.Trained{1};

%% Random Smaple
idx = randsample(sum(test_data),Partition.TestSize);
%% Prediction
[predict_labels1,PostProbs1,MisClassCost1] = predict(CMdl_1,X_test);

table(Y_test(idx),predict_labels1(idx),'VariableNames',...
    {'True_Label','Predicted_Label'})

XXX_1 = table(Y_test(idx),predict_labels1(idx),PostProbs1(idx),'VariableNames',...
    {'True_Labels','Predicted_Labels',...
    'PosteriorProbabilities'})

mdl_1_catt1 = categorical(table2array(XXX_1(:,1))); % True Label
mdl_1_catt2 = categorical(table2array(XXX_1(:,2))); % Predicted Label
%% Confusion matrix
figure,
cm_1 = confusionchart(mdl_1_catt1,mdl_1_catt2)
%% Add column and row summaries.
cm_1.RowSummary = 'row-normalized';
cm_1.ColumnSummary = 'column-normalized';
cm_1.Normalization = 'absolute'

%%



% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
aa = pwd;
%% Import the Data
load DataBase_Feature.mat
target_class = label_data;

XX = Dfeat;
YY = target_class;
%% Data Split 75% for Training & 25% for Test
NN = size(Dfeat,1);
rng('default') % For reproducibility
Partition = cvpartition(YY,'Holdout',0.228,'Stratify',true );%% 
test_data = test(Partition); % Indices for the test set
X_test = XX(test_data,:);
Y_test = YY(test_data);
%% Decision Tree
tTree = templateTree('MinLeafSize',20);
t = templateEnsemble('AdaBoostM1',100,tTree,'LearnRate',0.2);

Mdl = fitcecoc(XX,YY,'Learners',t,'CVPartition',Partition,'ScoreTransform','logit',...
                'ClassNames',{'AH-1 Cobra','UH-60 Black Hawak','A109 Agusta'...
                'AS332 Super Puma','Mil MI-2 Hoplite'}); %%%'CrossVal','on'
Mdl.CrossValidatedModel


Mdl.ScoreTransform
Mdl.NumObservations
CMdl_1 = Mdl.Trained{1};

%% Random Smaple
idx = randsample(sum(test_data),Partition.TestSize);
%% Prediction
[predict_labels1,PostProbs1,MisClassCost1] = predict(CMdl_1,X_test);

table(Y_test(idx),predict_labels1(idx),'VariableNames',...
    {'True_Label','Predicted_Label'})

XXX_1 = table(Y_test(idx),predict_labels1(idx),PostProbs1(idx),'VariableNames',...
    {'True_Labels','Predicted_Labels',...
    'PosteriorProbabilities'})

mdl_1_catt1 = categorical(table2array(XXX_1(:,1))); % True Label
mdl_1_catt2 = categorical(table2array(XXX_1(:,2))); % Predicted Label
%% Confusion matrix
figure,
cm_1 = confusionchart(mdl_1_catt1,mdl_1_catt2)
%% Add column and row summaries.
cm_1.RowSummary = 'row-normalized';
cm_1.ColumnSummary = 'column-normalized';
cm_1.Normalization = 'absolute'


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Main_File



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
